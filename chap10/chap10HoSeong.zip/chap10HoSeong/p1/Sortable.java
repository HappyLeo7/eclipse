package chap10HoSeong.p1;

import java.util.Comparator;

public interface Sortable {

	void sort(String[] s, Comparator<String> com);
}
