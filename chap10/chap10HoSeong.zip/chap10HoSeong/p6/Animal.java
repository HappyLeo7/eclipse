package chap10HoSeong.p6;

public class Animal {
	public void sound() {
		System.out.println("ㅁㅁㄲㄲ...");
	}

}
