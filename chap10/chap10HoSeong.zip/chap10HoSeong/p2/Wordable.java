package chap10HoSeong.p2;

public interface Wordable {

	void word();

}
