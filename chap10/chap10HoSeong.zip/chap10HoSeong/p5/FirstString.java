package chap10HoSeong.p5;

public class FirstString {

	String startsWith(String s) {
		return Character.toString(s.charAt(0)); // 받은값의 0번째 charAt 리턴
	}
}
