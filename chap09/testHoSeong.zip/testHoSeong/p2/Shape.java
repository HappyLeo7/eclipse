package testHoSeong.p2;

public class Shape {
	// 부모 생성
}
