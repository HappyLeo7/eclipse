package testHoSeong.p2;

public class Rectangle extends Shape {
	// 부모인 shape 상속받는 자식 생성
}
