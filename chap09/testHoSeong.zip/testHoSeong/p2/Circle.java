package testHoSeong.p2;

public class Circle extends Shape {
	// 부모인 shape을 상속받는 자식 생성(rectangle하곤 관계없음)
}
