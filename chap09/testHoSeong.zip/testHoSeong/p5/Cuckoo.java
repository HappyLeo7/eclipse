package testHoSeong.p5;

public class Cuckoo implements Animal {

	@Override
	public void sound() {

		System.out.println("뻐꾹 뻐꾹~~");
	}

}
