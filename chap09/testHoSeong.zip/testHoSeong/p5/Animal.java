package testHoSeong.p5;

public interface Animal {
	void sound();
}
