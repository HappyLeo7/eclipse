package testHoSeong.p1;

public class MyDate {

	// 변수값 지정
	int year = 2035;
	int month = 12;
	int day = 25;
}
